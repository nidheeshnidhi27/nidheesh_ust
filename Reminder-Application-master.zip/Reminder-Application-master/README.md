# Reminder-Application
It is a Java based simple Reminder Application
